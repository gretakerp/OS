#include "glo.h"

int Push(int* what)
{
	
	return TRUE;
}
//---------------------------------------
int Pop(int* what)
{
	return TRUE;
}
//---------------------------------------
int RunVM()
{
	while(SI==0 && PI==0 && TIME !=0){
		ExecuteInstruction();
		}
	return TRUE;
}
//---------------------------------------
//---------------------------------------
//---------------------------------------
