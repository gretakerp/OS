//Parameters for creating new HDD image.

#define SECTORS_IN_HDD 16
#define SECTOR_SIZE 512
