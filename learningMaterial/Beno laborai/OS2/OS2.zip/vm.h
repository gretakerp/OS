int Push(int* what);
int Pop(int* what);
int RunVM();
